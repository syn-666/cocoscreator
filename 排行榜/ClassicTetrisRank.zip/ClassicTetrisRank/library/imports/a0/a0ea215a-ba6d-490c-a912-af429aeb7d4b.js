"use strict";
cc._RF.push(module, 'a0ea2Faum1JDKkSr0Ka631L', 'GameRankingList');
// Script/GameRankingList.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        rankingScrollView: cc.ScrollView,
        scrollViewContent: cc.Node,
        prefabRankItem: cc.Prefab,
        prefabGameOverRank: cc.Prefab,
        gameOverRankLayout: cc.Node,
        myRank: cc.Node,
        loadingLabel: cc.Node //加载文字
    },

    start: function start() {
        var _this = this;

        this.removeChild();

        wx.onMessage(function (data) {
            console.log("接收主域发来消息：", data);
            if (data.messageType == 0) {
                //移除排行榜
                _this.removeChild();
            } else if (data.messageType == 1) {
                //获取好友排行榜
                _this.fetchFriendData(data.MAIN_MENU_NUM);
            } else if (data.messageType == 3) {
                //提交得分
                _this.submitScore(data.MAIN_MENU_NUM, data.score);
            } else if (data.messageType == 4) {
                //获取好友排行榜横向排列展示模式
                _this.gameOverRank(data.MAIN_MENU_NUM);
            } else if (data.messageType == 5) {
                //获取群排行榜
                _this.fetchGroupFriendData(data.MAIN_MENU_NUM, data.shareTicket);
            }
        });
    },
    submitScore: function submitScore(MAIN_MENU_NUM, score) {
        //提交得分

        wx.getUserCloudStorage({
            // 以key/value形式存储
            keyList: [MAIN_MENU_NUM],
            success: function success(getres) {
                console.log('getUserCloudStorage', 'success', getres);
                if (getres.KVDataList.length != 0) {
                    if (parseInt(getres.KVDataList[0].value) > parseInt(score) && parseInt(score) != 0) {
                        console.log("submit update");
                        return;
                    }
                }
                // 对用户托管数据进行写数据操作
                wx.setUserCloudStorage({
                    KVDataList: [{ key: MAIN_MENU_NUM, value: "" + score }],
                    success: function success(res) {
                        console.log('setUserCloudStorage', 'success', res);
                    },
                    fail: function fail(res) {
                        console.log('setUserCloudStorage', 'fail');
                    },
                    complete: function complete(res) {
                        console.log('setUserCloudStorage', 'ok');
                    }
                });
            },
            fail: function fail(res) {
                console.log('getUserCloudStorage', 'fail');
            },
            complete: function complete(res) {
                console.log('getUserCloudStorage', 'ok');
            }
        });
    },
    removeChild: function removeChild() {
        //this.node.removeChildByTag(1000);
        this.rankingScrollView.node.active = false;
        this.scrollViewContent.removeAllChildren();
        this.gameOverRankLayout.active = false;
        this.gameOverRankLayout.removeAllChildren();
        this.myRank.active = false;
        this.myRank.removeAllChildren();
        this.loadingLabel.getComponent(cc.Label).string = "全力加载中";
        this.loadingLabel.active = true;
    },
    fetchFriendData: function fetchFriendData(MAIN_MENU_NUM) {
        var _this2 = this;

        this.removeChild();
        this.rankingScrollView.node.active = true;
        this.myRank.active = true;
        wx.getUserInfo({
            openIdList: ['selfOpenId'],
            success: function success(userRes) {
                _this2.loadingLabel.active = false;
                console.log('success', userRes.data);
                var userData = userRes.data[0];
                //取出所有好友数据
                wx.getFriendCloudStorage({
                    keyList: [MAIN_MENU_NUM],
                    success: function success(res) {
                        console.log("wx.getFriendCloudStorage success", res);
                        var data = res.data;
                        data.sort(function (a, b) {
                            if (a.KVDataList.length == 0 && b.KVDataList.length == 0) {
                                return 0;
                            }
                            if (a.KVDataList.length == 0) {
                                return 1;
                            }
                            if (b.KVDataList.length == 0) {
                                return -1;
                            }
                            return b.KVDataList[0].value - a.KVDataList[0].value;
                        });
                        _this2.scrollViewContent.removeAllChildren();
                        _this2.myRank.removeAllChildren();
                        for (var i = 0; i < data.length; i++) {
                            var playerInfo = data[i];
                            var item = cc.instantiate(_this2.prefabRankItem);
                            item.getComponent('RankItem').init(i, playerInfo);
                            _this2.scrollViewContent.addChild(item);
                            if (data[i].avatarUrl == userData.avatarUrl) {
                                var userItem = cc.instantiate(_this2.prefabRankItem);
                                userItem.getComponent('RankItem').init(i, playerInfo);
                                //userItem.y = -370;
                                _this2.myRank.addChild(userItem, 1, 1000);
                            }
                        }
                        // if (data.length <= 8) {
                        //     let layout = this.scrollViewContent.getComponent(cc.Layout);
                        //     layout.resizeMode = cc.Layout.ResizeMode.NONE;
                        // }
                    },
                    fail: function fail(res) {
                        console.log("wx.getFriendCloudStorage fail", res);
                        _this2.loadingLabel.getComponent(cc.Label).string = "数据加载失败，请检测网络，谢谢。";
                    }
                });
            },
            fail: function fail(res) {
                _this2.loadingLabel.getComponent(cc.Label).string = "数据加载失败，请检测网络，谢谢。";
            }
        });
    },
    fetchGroupFriendData: function fetchGroupFriendData(MAIN_MENU_NUM, shareTicket) {
        var _this3 = this;

        this.removeChild();
        this.rankingScrollView.node.active = true;
        this.myRank.active = true;
        wx.getUserInfo({
            openIdList: ['selfOpenId'],
            success: function success(userRes) {
                console.log('success', userRes.data);
                var userData = userRes.data[0];
                //取出所有好友数据
                wx.getGroupCloudStorage({
                    shareTicket: shareTicket,
                    keyList: [MAIN_MENU_NUM],
                    success: function success(res) {
                        console.log("wx.getGroupCloudStorage success", res);
                        _this3.loadingLabel.active = false;
                        var data = res.data;
                        data.sort(function (a, b) {
                            if (a.KVDataList.length == 0 && b.KVDataList.length == 0) {
                                return 0;
                            }
                            if (a.KVDataList.length == 0) {
                                return 1;
                            }
                            if (b.KVDataList.length == 0) {
                                return -1;
                            }
                            return b.KVDataList[0].value - a.KVDataList[0].value;
                        });
                        _this3.scrollViewContent.removeAllChildren();
                        _this3.myRank.removeAllChildren();
                        for (var i = 0; i < data.length; i++) {
                            var playerInfo = data[i];
                            var item = cc.instantiate(_this3.prefabRankItem);
                            item.getComponent('RankItem').init(i, playerInfo);
                            _this3.scrollViewContent.addChild(item);
                            if (data[i].avatarUrl == userData.avatarUrl) {
                                var userItem = cc.instantiate(_this3.prefabRankItem);
                                userItem.getComponent('RankItem').init(i, playerInfo);
                                //userItem.y = -370;
                                _this3.myRank.addChild(userItem, 1, 1000);
                            }
                        }
                        // if (data.length <= 8) {
                        //     let layout = this.scrollViewContent.getComponent(cc.Layout);
                        //     layout.resizeMode = cc.Layout.ResizeMode.NONE;
                        // }
                    },
                    fail: function fail(res) {
                        console.log("wx.getFriendCloudStorage fail", res);
                        _this3.loadingLabel.getComponent(cc.Label).string = "数据加载失败，请检测网络，谢谢。";
                    }
                });
            },
            fail: function fail(res) {
                _this3.loadingLabel.getComponent(cc.Label).string = "数据加载失败，请检测网络，谢谢。";
            }
        });
    },
    gameOverRank: function gameOverRank(MAIN_MENU_NUM) {
        var _this4 = this;

        this.removeChild();
        this.gameOverRankLayout.active = true;

        wx.getUserInfo({
            openIdList: ['selfOpenId'],
            success: function success(userRes) {
                cc.log('success', userRes.data);
                var userData = userRes.data[0];
                //取出所有好友数据
                wx.getFriendCloudStorage({
                    keyList: [MAIN_MENU_NUM],
                    success: function success(res) {
                        cc.log("wx.getFriendCloudStorage success", res);
                        _this4.loadingLabel.active = false;
                        var data = res.data;
                        data.sort(function (a, b) {
                            if (a.KVDataList.length == 0 && b.KVDataList.length == 0) {
                                return 0;
                            }
                            if (a.KVDataList.length == 0) {
                                return 1;
                            }
                            if (b.KVDataList.length == 0) {
                                return -1;
                            }
                            return b.KVDataList[0].value - a.KVDataList[0].value;
                        });
                        for (var i = 0; i < data.length; i++) {
                            if (data[i].avatarUrl == userData.avatarUrl) {
                                if (i - 1 >= 0) {
                                    if (i + 1 >= data.length && i - 2 >= 0) {
                                        var _userItem2 = cc.instantiate(_this4.prefabGameOverRank);
                                        _userItem2.getComponent('GameOverRank').init(i - 2, data[i - 2]);
                                        _this4.gameOverRankLayout.addChild(_userItem2);
                                    }
                                    var _userItem = cc.instantiate(_this4.prefabGameOverRank);
                                    _userItem.getComponent('GameOverRank').init(i - 1, data[i - 1]);
                                    _this4.gameOverRankLayout.addChild(_userItem);
                                } else {
                                    if (i + 2 >= data.length) {
                                        var node = new cc.Node();
                                        node.width = 180;
                                        _this4.gameOverRankLayout.addChild(node);
                                    }
                                }
                                var userItem = cc.instantiate(_this4.prefabGameOverRank);
                                userItem.getComponent('GameOverRank').init(i, data[i], true);
                                _this4.gameOverRankLayout.addChild(userItem);
                                if (i + 1 < data.length) {
                                    var _userItem3 = cc.instantiate(_this4.prefabGameOverRank);
                                    _userItem3.getComponent('GameOverRank').init(i + 1, data[i + 1]);
                                    _this4.gameOverRankLayout.addChild(_userItem3);
                                    if (i - 1 < 0 && i + 2 < data.length) {
                                        var _userItem4 = cc.instantiate(_this4.prefabGameOverRank);
                                        _userItem4.getComponent('GameOverRank').init(i + 2, data[i + 2]);
                                        _this4.gameOverRankLayout.addChild(_userItem4);
                                    }
                                }
                            }
                        }
                    },
                    fail: function fail(res) {
                        console.log("wx.getFriendCloudStorage fail", res);
                        _this4.loadingLabel.getComponent(cc.Label).string = "数据加载失败，请检测网络，谢谢。";
                    }
                });
            },
            fail: function fail(res) {
                _this4.loadingLabel.getComponent(cc.Label).string = "数据加载失败，请检测网络，谢谢。";
            }
        });
    }
});

cc._RF.pop();