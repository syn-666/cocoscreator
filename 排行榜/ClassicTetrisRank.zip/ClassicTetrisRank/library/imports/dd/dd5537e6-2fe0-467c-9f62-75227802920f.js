"use strict";
cc._RF.push(module, 'dd553fmL+BGfJ9idSJ4ApIP', 'RankItem');
// Script/RankItem.js

"use strict";

cc.Class({
    extends: cc.Component,
    name: "RankItem",
    properties: {
        backSprite: cc.Node,
        rankLabel: cc.Label,
        avatarImgSprite: cc.Sprite,
        nickLabel: cc.Label,
        topScoreLabel: cc.Label
    },
    start: function start() {},


    init: function init(rank, data) {
        var avatarUrl = data.avatarUrl;
        // let nick = data.nickname.length <= 10 ? data.nickname : data.nickname.substr(0, 10) + "...";
        var nick = data.nickname;
        var grade = data.KVDataList.length != 0 ? data.KVDataList[0].value : 0;

        if (rank % 2 == 0) {
            this.backSprite.color = new cc.Color(55, 55, 55, 255);
        }

        if (rank == 0) {
            this.rankLabel.node.color = new cc.Color(255, 0, 0, 255);
            this.rankLabel.node.setScale(1.8);
        } else if (rank == 1) {
            this.rankLabel.node.color = new cc.Color(255, 255, 0, 255);
            this.rankLabel.node.setScale(1.4);
        } else if (rank == 2) {
            this.rankLabel.node.color = new cc.Color(100, 255, 0, 255);
            this.rankLabel.node.setScale(1.2);
        }
        this.rankLabel.string = (rank + 1).toString();
        this.createImage(avatarUrl);
        this.nickLabel.string = nick;
        this.topScoreLabel.string = grade.toString();
    },
    createImage: function createImage(avatarUrl) {
        var _this = this;

        try {
            var image = wx.createImage();
            image.onload = function () {
                try {
                    var texture = new cc.Texture2D();
                    texture.initWithElement(image);
                    texture.handleLoadedTexture();
                    _this.avatarImgSprite.spriteFrame = new cc.SpriteFrame(texture);
                } catch (e) {
                    cc.log(e);
                    _this.avatarImgSprite.node.active = false;
                }
            };
            image.src = avatarUrl;
        } catch (e) {
            cc.log(e);
            this.avatarImgSprite.node.active = false;
        }
    }
});

cc._RF.pop();